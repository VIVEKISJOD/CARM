// DEMO CATALOGUE ONLY. Fictional vehicles so no real specs/prices are invented.
// Real data must come from official/licensed providers (planned step). Every record carries source + status.
const SOURCE={name:'CARM demo data',verified:false,updated:'2026-11-16'};
const YEARS={d1:2024,d2:2025,d3:2025,d4:2024,d5:2026,d6:2026,d7:2023,d8:2026,d9:2025}; // demo values
const DEMO_CARS=[
{id:'d1',make:'Demo',model:'City Hatch',variant:'1.2 Petrol MT',type:'Hatchback',fuel:'Petrol',trans:'Manual',price:650000,mileage:20,seats:5,safety:3,features:['Rear camera','Android Auto','Apple CarPlay']},
{id:'d2',make:'Demo',model:'City Hatch',variant:'1.2 Petrol AMT',type:'Hatchback',fuel:'Petrol',trans:'AMT',price:720000,mileage:19,seats:5,safety:3,features:['Rear camera','Android Auto','Apple CarPlay','Cruise control']},
{id:'d3',make:'Demo',model:'Urban SUV',variant:'1.5 Petrol AT',type:'SUV',fuel:'Petrol',trans:'Automatic',price:1150000,mileage:15,seats:5,safety:5,features:['Sunroof','Rear camera','Android Auto','Apple CarPlay','Cruise control','Automatic climate control']},
{id:'d4',make:'Demo',model:'Urban SUV',variant:'1.5 Diesel MT',type:'SUV',fuel:'Diesel',trans:'Manual',price:1250000,mileage:20,seats:5,safety:5,features:['Sunroof','Rear camera','Android Auto','ADAS']},
{id:'d5',make:'Demo',model:'Compact Cross',variant:'1.2 Petrol CVT',type:'Compact SUV',fuel:'Petrol',trans:'CVT',price:1050000,mileage:17,seats:5,safety:4,features:['Rear camera','Apple CarPlay','Cruise control','Automatic climate control']},
{id:'d6',make:'Demo',model:'Compact Cross',variant:'1.2 Petrol Sunroof AT',type:'Compact SUV',fuel:'Petrol',trans:'Automatic',price:1290000,mileage:16,seats:5,safety:4,features:['Sunroof','360 camera','Rear camera','Apple CarPlay','Android Auto']},
{id:'d7',make:'Demo',model:'Family Van',variant:'1.5 CNG MT',type:'MUV/MPV',fuel:'CNG',trans:'Manual',price:1000000,mileage:26,seats:7,safety:3,features:['Rear camera','Android Auto']},
{id:'d8',make:'Demo',model:'Volt EV',variant:'Long Range',type:'EV',fuel:'Electric',trans:'Automatic',price:1490000,mileage:0,seats:5,safety:5,features:['Sunroof','360 camera','ADAS','Apple CarPlay','Android Auto','Automatic climate control']},
{id:'d9',make:'Demo',model:'Exec Sedan',variant:'1.5 Petrol DCT',type:'Sedan',fuel:'Petrol',trans:'DCT',price:1350000,mileage:16,seats:5,safety:5,features:['Sunroof','Rear camera','Cruise control','Apple CarPlay','Android Auto','Ventilated seats']}
].map(c=>({...c,year:YEARS[c.id],status:'Availability Unverified',src:SOURCE}));
const COUNTRIES={India:{cur:'INR',loc:'en-IN',states:['Maharashtra','Delhi','Karnataka','Gujarat','Tamil Nadu','Uttar Pradesh','Other']},'Other (coming soon)':{cur:'USD',loc:'en-US',states:['Other']}};
const FEATURES=['Sunroof','360 camera','Rear camera','ADAS','Ventilated seats','Android Auto','Apple CarPlay','Cruise control','Automatic climate control'];
const TYPES=['Hatchback','Sedan','SUV','Compact SUV','MUV/MPV','Coupe','Convertible','Pickup','Luxury','EV'];
const FUELS=['Petrol','Diesel','CNG','Hybrid','Electric'];
const TRANS=['Manual','Automatic','AMT','CVT','DCT'];
const STAGES=['New Lead','Contacted','Requirements Collected','Cars Suggested','Interested','Test Drive','Negotiation','Booking','Delivered','Lost'];
const GLOSS={AMT:'Automated manual: a manual gearbox that shifts by itself',CVT:'Smooth automatic with no fixed gears',DCT:'Fast-shifting automatic with two clutches',ADAS:'Driver-assist safety (auto braking, lane help)'};
