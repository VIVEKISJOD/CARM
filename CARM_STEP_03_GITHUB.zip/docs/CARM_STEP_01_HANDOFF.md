# CARM — Handoff, Step 01
- Project: CARM (formerly AUTOHUB, name is a single string in index.html/manifest/app.js)
- Step: 01 — Foundation (PWA, GitHub Pages ready)
- Date: 2026-11-16 · Version: 0.1.0 · ZIP: CARM_STEP_01_GITHUB.zip · Previous step: none

## Status
Working foundation, plain HTML/CSS/JS (no build tools, no dependencies) so it deploys straight to GitHub Pages and installs as an Android/PC app.

## Done
First-launch setup (country, state, city, language) · bottom nav (Home, Explore, Customers, Stock, More) · Home dashboard with quick actions · Explore (search, demo catalogue with source/status on every record) · Find My Customer's Car (Must/Preferred per item, 3 result groups, explainable "x of y preferences met", saved to customer) · Customers (add, lead stage, follow-up date, saved demands) · Stock (add new/used, status) · Settings: Simple/Pro mode, light/dark/system, text size, English/Hindi (nav + key titles only), JSON backup · offline cache (sw.js).

## Files
index.html, manifest.webmanifest, sw.js, css/styles.css, js/app.js (all logic), js/data.js (demo catalogue + lists), icons/, .github/workflows/pages.yml, README.md.

## Architecture
Single-page app, hash routing, state in localStorage key carm_v1. Catalogue is replaceable: DEMO_CARS in data.js uses the planned global schema fields (make, model, variant, type, fuel, trans, price, status, src). Matching rules in app.js: seats and Must items are hard filters; budget up to +15% = stretch.

## Not implemented
Real verified car database and country availability layer · Hindi for all screens · customer profile tabs, information-shared tracker, communication history · quotations/PDF · EMI/finance calculators · AI assistant · analytics · team/login/cloud sync (data is device-only) · photos/documents upload · voice input · customisable stages · comparison.

## Known limits
Not tested in a real browser or on a phone (no browser in my environment); only JS syntax and the matching logic were checked. Icons are placeholders. Prices are in INR only. Data is lost if browser storage is cleared (use backup).

## Config / keys
None required.

## Next (Step 02)
Customer profile with tabs + Information Shared Tracker + follow-up manager (reminders, overdue, call notes); then data-provider design for the real catalogue. Android APK wrapper (via PWABuilder or Capacitor build in GitHub Actions) as a separate step.
