# CARM — Handoff, Step 03
- Project: CARM · Step 03 — Polish, search, logo and in-app updater · Date: 2026-11-16 · Version: 0.3.0
- ZIP: CARM_STEP_03_GITHUB.zip · Previous step: Step 02 / 02B (APK build, build.yml)

## Done
1. No emojis anywhere in the UI: nav and quick actions use inline SVG icons (js/app.js IC/ic()); ratings written as text.
2. Explore keyword search (js/app.js exploreList/parseQ): words like manual, automatic (includes AMT/CVT/DCT), petrol, diesel, CNG, electric, model/variant/type, 4-digit year, "7 seater"/"seats 7", "5 star"/"safety 5". Words are combined with AND. Plus dropdown filters: fuel, gearbox, year, seats, minimum safety. Demo cars got a demo 'year' field (js/data.js YEARS).
3. Logo: in-app logo (onboarding, Home); Android launcher icon is generated from icons/icon-512.png in the workflow (adaptive icon, black background). Upload logo.png to repo root to replace everywhere, no ZIP change.
4. In-app updater: workflow writes js/version.js (build number = GitHub run number, repo name). In the Android app only, js/app.js checkUpdate() reads GitHub latest Release (tag apk-N), compares N with this build, shows banner on Home and a card in More with Download update (opens CARM.apk in browser; user taps to install). Needs a PUBLIC repo and internet.
5. build.yml restructured: prepare job (unzip newest ZIP, apply logo.png, write version.js) then apk and pages jobs. APK versionCode = run number so updates install. APK signed with signing/debug.keystore (copied to ~/.android/debug.keystore) so every build has the SAME signature.

## Files
index.html, manifest.webmanifest, sw.js (cache v3), css/styles.css, js/app.js, js/data.js, js/version.js (placeholder, overwritten in CI), icons/, signing/debug.keystore (test key, password android, alias androiddebugkey — NEVER regenerate, carry it into every future ZIP), docs/ (handoff, changelog, build.yml copy), README.md. Old Capacitor files and old workflows were removed from the ZIP: build.yml generates package.json and capacitor.config.json itself (appId com.carm.app).

## Not verified
Tested here: JS syntax, Explore search logic (12 queries), icon generation commands (ImageMagick), version.js output, YAML parse. NOT tested: real Android build, launcher icon on device, updater inside the APK (uses window.Capacitor / WebView check; window.open to download may behave differently), website rendering. First launch of this build after an older APK needs ONE uninstall (old APK used a different random key); later updates install over the top.

## Not implemented yet
Everything in Step 01 'Not implemented' list. Hindi still partial.

## Next
Step 04: customer profile tabs, Information Shared tracker, follow-up manager. Then real data-provider design.
