# CARM — Changelog, Step 03
Project: CARM · Step 03 · ZIP: CARM_STEP_03_GITHUB.zip · Version: 0.3.0 · Date: 2026-11-16
## Added
Explore keyword search + filters (fuel, gearbox, year, seats, safety); demo year field; in-app logo; Android launcher icon generation from logo; logo.png override; in-app update checker (Home banner, More > Check for updates); js/version.js build info; fixed signing key signing/debug.keystore; APK versionCode from build number; website cache v3.
## Modified
Nav and quick actions now SVG icons; safety shown as "N star safety"; matcher reasons say "(matched)" instead of tick marks; build.yml split into prepare/apk/pages jobs; README.
## Removed
All emojis/symbol icons; old package.json, capacitor.config.json, scripts/, .github/ from the ZIP (build.yml generates them).
## Fixed
Search box keeps typing focus after each keystroke (focus restored by id).
## Security
Test signing key is in the repo (fine for personal testing; replace before store release). Keystore and docs are excluded from the published website.
## Known issues
See handoff (untested on device; update download needs public repo; one-time uninstall needed when moving from older APK).
## Breaking changes
Different signing key than earlier APKs: uninstall the old CARM APK once.
