# CARM — Handoff, Step 02
- Project: CARM · Step 02 — Android APK build · Date: 2026-11-16 · Version: 0.2.0
- ZIP: CARM_STEP_02_GITHUB.zip · Previous step: Step 01 (PWA foundation, v0.1.0)

## Status
Step 1 app unchanged (same website code). Added a Capacitor wrapper so GitHub Actions builds an installable Android APK from the same code. Website on GitHub Pages and the APK share one codebase.

## Added files
package.json (Capacitor 6), capacitor.config.json (appId com.carm.app, appName CARM, webDir www), scripts/build-web.js (copies site into www/), .github/workflows/build-apk.yml (Node 20, Java 17: npm install → build:web → cap add android → cap sync → gradlew assembleDebug → uploads artifact CARM-APK). README updated. .gitignore now excludes android/ and www/ (generated each build, never committed).

## Decisions
android/ is generated fresh in CI so the repo stays small and the user never edits native files. Debug APK = installable on phone without Play Store, not for store release.

## Known limits / NOT verified
I could NOT run the APK build (no internet/Android SDK in my environment). Only build-web.js was run locally. First GitHub run may need small fixes; send the error text/log and the next step fixes it. APK icon is the default Capacitor icon (logo not yet applied to Android launcher). No release signing, no Play Store config. Features still as listed in Step 01 handoff.

## Next
1) Confirm APK builds; fix workflow if not. 2) Launcher icon from user's logo (+ splash). 3) Then Step 01 'Next' list: customer profile tabs, information-shared tracker, follow-up manager.
