# CARM — Changelog, Step 01
Project: CARM · Step 01 Foundation · ZIP: CARM_STEP_01_GITHUB.zip · Version: 0.1.0 · Date: 2026-11-16

## Added
First-run setup; 5-tab bottom navigation; Home dashboard; Explore with search; Find My Customer's Car matcher; Customers with stages and follow-up date; Stock with 6 statuses; Simple/Professional mode; light/dark/system theme; text size; English/Hindi (partial); JSON backup; PWA manifest, service worker, placeholder icons; GitHub Pages workflow.
## Modified / Fixed / Removed
None (first version).
## UI
Black/yellow styling matching the logo, large touch targets, bigger buttons in Simple Mode.
## Backend / Database
None; localStorage only.
## Security
All user text is HTML-escaped before display; no keys or secrets; data stays on device.
## Known issues
See handoff (untested in a browser; demo data only; Hindi partial).
## Breaking changes
None.
