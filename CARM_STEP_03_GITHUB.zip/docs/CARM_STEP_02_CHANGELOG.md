# CARM — Changelog, Step 02
Project: CARM · Step 02 Android APK build · ZIP: CARM_STEP_02_GITHUB.zip · Version: 0.2.0 · Date: 2026-11-16
## Added
Capacitor Android wrapper (package.json, capacitor.config.json); build-web script; GitHub Actions workflow producing downloadable CARM-APK artifact; README instructions for APK.
## Modified
.gitignore (ignores android/, www/); package version 0.2.0; README.
## Fixed / Removed / UI / Backend / Database
None.
## Security
Debug build only; no keys or signing secrets in repo.
## Known issues
APK build not yet verified; default launcher icon; see handoff.
## Breaking changes
None.
