# CARM
Automotive sales, customer and stock app (India first). Runs in any browser (GitHub Pages) and as an Android app (APK).

## How building works (no unzipping, no extra files)
1. Upload the newest `CARM_STEP_xx_GITHUB.zip` to the repository root (keep the file `.github/workflows/build.yml` — copy in `docs/build.yml`).
2. GitHub unzips the newest ZIP by itself and builds:
   - Android APK: **Releases** page, file `CARM.apk`
   - Website: `https://<username>.github.io/<repo>/` (one time: Settings > Pages > Source: GitHub Actions)
3. Update the installed app: open **More > Check for updates** inside the app (repository must be public), or install the newest `CARM.apk` over the old one.

## Logo
Upload a file named `logo.png` to the repository root. The next build uses it for the Android icon, website icon and in-app logo. No ZIP change needed.

## Signing key
`signing/debug.keystore` is a test key kept so each new APK installs over the old one without uninstalling. Not for Play Store; a private release key will be made before publishing.

## Data
Stored only on the device. Use **More > Download backup**. The Explore catalogue is DEMO data (fictional cars).

See `docs/` for handoff, changelog and a copy of build.yml.
