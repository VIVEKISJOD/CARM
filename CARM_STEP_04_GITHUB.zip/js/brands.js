// Company and model NAME list for India. Compiled from general knowledge, NOT verified or official.
// No prices/specs here on purpose. Empty fuel list = not listed. Replace with licensed/official data later.
const _B=[
['Maruti Suzuki','Japan',['Alto K10|Hatchback|Petrol,CNG','Wagon R|Hatchback|Petrol,CNG','Swift|Hatchback|Petrol,CNG','Dzire|Sedan|Petrol,CNG','Baleno|Hatchback|Petrol,CNG','Fronx|Compact SUV|Petrol,CNG','Brezza|Compact SUV|Petrol,CNG','Grand Vitara|SUV|Petrol,Hybrid,CNG','Ertiga|MUV/MPV|Petrol,CNG','Jimny|SUV|Petrol','Invicto|MUV/MPV|Hybrid']],
['Hyundai','South Korea',['Grand i10 Nios|Hatchback|Petrol,CNG','i20|Hatchback|Petrol','Aura|Sedan|Petrol,CNG','Verna|Sedan|Petrol','Exter|Compact SUV|Petrol,CNG','Venue|Compact SUV|Petrol,Diesel','Creta|SUV|Petrol,Diesel','Alcazar|SUV|Petrol,Diesel','Tucson|SUV|Petrol,Diesel','Creta Electric|SUV|Electric']],
['Tata Motors','India',['Tiago|Hatchback|Petrol,CNG','Tigor|Sedan|Petrol,CNG','Altroz|Hatchback|Petrol,Diesel,CNG','Punch|Compact SUV|Petrol,CNG,Electric','Nexon|Compact SUV|Petrol,Diesel,CNG,Electric','Curvv|SUV|Petrol,Diesel,Electric','Harrier|SUV|Diesel,Electric','Safari|SUV|Diesel']],
['Mahindra','India',['Thar|SUV|Petrol,Diesel','Thar Roxx|SUV|Petrol,Diesel','Scorpio N|SUV|Petrol,Diesel','Scorpio Classic|SUV|Diesel','XUV 3XO|Compact SUV|Petrol,Diesel','XUV700|SUV|Petrol,Diesel','Bolero|SUV|Diesel','BE 6|SUV|Electric','XEV 9e|SUV|Electric']],
['Kia','South Korea',['Sonet|Compact SUV|Petrol,Diesel','Seltos|SUV|Petrol,Diesel','Syros|Compact SUV|Petrol,Diesel','Carens|MUV/MPV|Petrol,Diesel','Carnival|MUV/MPV|Diesel']],
['Toyota','Japan',['Glanza|Hatchback|Petrol,CNG','Urban Cruiser Taisor|Compact SUV|Petrol,CNG','Urban Cruiser Hyryder|SUV|Petrol,Hybrid,CNG','Rumion|MUV/MPV|Petrol,CNG','Innova Crysta|MUV/MPV|Diesel','Innova Hycross|MUV/MPV|Petrol,Hybrid','Fortuner|SUV|Petrol,Diesel','Hilux|Pickup|Diesel','Camry|Sedan|Hybrid']],
['Honda','Japan',['Amaze|Sedan|Petrol','City|Sedan|Petrol,Hybrid','Elevate|SUV|Petrol']],
['MG','UK brand, owned by SAIC (China)',['Comet EV|Hatchback|Electric','Windsor EV|Crossover|Electric','Astor|SUV|Petrol','Hector|SUV|Petrol,Diesel','Gloster|SUV|Diesel','ZS EV|SUV|Electric']],
['Skoda','Czech Republic',['Kylaq|Compact SUV|Petrol','Slavia|Sedan|Petrol','Kushaq|SUV|Petrol','Kodiaq|SUV|Petrol']],
['Volkswagen','Germany',['Virtus|Sedan|Petrol','Taigun|SUV|Petrol','Tiguan|SUV|Petrol']],
['Renault','France',['Kwid|Hatchback|Petrol','Triber|MUV/MPV|Petrol','Kiger|Compact SUV|Petrol']],
['Nissan','Japan',['Magnite|Compact SUV|Petrol','X-Trail|SUV|Petrol']],
['Citroen','France',['C3|Hatchback|Petrol','C3 Aircross|Compact SUV|Petrol','Basalt|SUV|Petrol','eC3|Hatchback|Electric']],
['Jeep','USA',['Compass|SUV|','Meridian|SUV|','Wrangler|SUV|']],
['BYD','China',['Atto 3|SUV|Electric','Seal|Sedan|Electric','eMAX 7|MUV/MPV|Electric','Sealion 7|SUV|Electric']],
['Isuzu','Japan',['D-Max V-Cross|Pickup|Diesel','MU-X|SUV|Diesel']],
['BMW','Germany',['3 Series Gran Limousine|Sedan|','5 Series|Sedan|','7 Series|Sedan|','X1|SUV|','X3|SUV|','X5|SUV|','iX1|SUV|Electric']],
['Mercedes-Benz','Germany',['C-Class|Sedan|','E-Class|Sedan|','S-Class|Sedan|','GLA|SUV|','GLC|SUV|','GLE|SUV|','GLS|SUV|']],
['Audi','Germany',['A6|Sedan|','Q3|SUV|','Q5|SUV|','Q7|SUV|']],
['Land Rover','UK (owned by Tata Motors group)',['Defender|SUV|','Range Rover|SUV|','Range Rover Sport|SUV|','Range Rover Evoque|SUV|','Discovery Sport|SUV|']],
['Volvo','Sweden',['XC60|SUV|','XC90|SUV|','EX40|SUV|Electric']]
];
const BRANDS=_B.map(([name,country,m])=>({name,country,models:m.map(x=>{const[a,b,c]=x.split('|');return[a,b,c?c.split(','):[]]})}));
