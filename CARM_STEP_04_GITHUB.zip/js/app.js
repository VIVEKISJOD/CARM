'use strict';
const KEY='carm_v1';
const BUILD=window.CARM_BUILD||{n:0,repo:''};
const T={en:{home:'Home',explore:'Explore',customers:'Customers',stock:'Stock',more:'More',welcome:'Welcome',find:'Find My Customer\'s Car',addc:'Add Customer',addv:'Add Vehicle'},
hi:{home:'होम',explore:'खोजें',customers:'ग्राहक',stock:'स्टॉक',more:'और',welcome:'स्वागत है',find:'ग्राहक की कार खोजें',addc:'ग्राहक जोड़ें',addv:'वाहन जोड़ें'}};
let S=load();
function load(){try{const s=JSON.parse(localStorage.getItem(KEY));if(s)return s}catch(e){}
 return{profile:null,set:{mode:'simple',theme:'system',text:100,lang:'en'},customers:[],stock:[],demands:[]}}
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){toast('Could not save')}}
const t=k=>(T[S.set.lang]||T.en)[k]||T.en[k]||k;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const $=s=>document.querySelector(s);
const money=n=>'₹'+Number(n).toLocaleString((COUNTRIES[S.profile?.country]||COUNTRIES.India).loc);
function toast(m){const e=$('#toast');e.textContent=m;e.classList.add('on');setTimeout(()=>e.classList.remove('on'),1800)}
function applySettings(){const b=document.body;b.className=[S.set.mode,S.set.theme==='dark'?'dark':S.set.theme==='system'?'sys':''].join(' ');
 document.documentElement.style.setProperty('--fs',S.set.text+'%');document.documentElement.lang=S.set.lang}
const allCars=()=>DEMO_CARS;
const opts=(a,sel)=>a.map(x=>`<option ${x===sel?'selected':''}>${esc(x)}</option>`).join('');
const val=id=>($('#'+id)||{}).value;

// ---------- Onboarding ----------
function onboarding(){
 $('#nav').classList.add('hide');
 $('#app').innerHTML=`<img class="logo big" src="icons/icon-512.png" alt="CARM"><h1>Welcome to CARM</h1><p class="mu">Let's set up your app. It takes 20 seconds.</p>
 <label>Country</label><select id="oc">${opts(Object.keys(COUNTRIES),'India')}</select>
 <label>State / region</label><select id="os"></select>
 <label>City</label><input id="ocity" placeholder="e.g. Pune">
 <label>Language</label><select id="ol"><option value="en">English</option><option value="hi">हिन्दी</option></select>
 <button class="btn full" id="od">Start</button>`;
 const fillS=()=>$('#os').innerHTML=opts(COUNTRIES[val('oc')].states);fillS();$('#oc').onchange=fillS;
 $('#od').onclick=()=>{S.profile={country:val('oc'),state:val('os'),city:val('ocity').trim()};S.set.lang=val('ol');save();applySettings();location.hash='#home';render()}}

// ---------- Icons (inline SVG, no emojis) ----------
const IC={home:'<path d="M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
compass:'<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
users:'<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><circle cx="17.5" cy="9" r="2.5"/><path d="M17 14.2c2.7.3 4.5 2.2 4.5 5.3"/>',
car:'<path d="M3 15l1.6-5.2A2 2 0 0 1 6.5 8.5h11a2 2 0 0 1 1.9 1.3L21 15v4h-3v-2H6v2H3z"/><circle cx="7.5" cy="13.5" r="1"/><circle cx="16.5" cy="13.5" r="1"/>',
dots:'<circle cx="5" cy="12" r="1.7" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.7" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.7" fill="currentColor" stroke="none"/>',
search:'<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
userplus:'<circle cx="10" cy="8" r="3.5"/><path d="M3 20c0-3.6 3-6 7-6s7 2.4 7 6M19 8v6M16 11h6"/>'};
const ic=n=>`<svg class="ic" viewBox="0 0 24 24" aria-hidden="true">${IC[n]}</svg>`;

// ---------- Update checker (Android app only) ----------
const IS_APP=!!(window.Capacitor&&window.Capacitor.isNativePlatform&&window.Capacitor.isNativePlatform())||/; wv\)/.test(navigator.userAgent);
let UPD=null;
async function checkUpdate(manual){
 if(!IS_APP){if(manual)toast('The website updates by itself. Reload the page.');return}
 if(!BUILD.repo){if(manual)toast('Updater is not set up in this build');return}
 try{const r=await fetch('https://api.github.com/repos/'+BUILD.repo+'/releases/latest');
  if(!r.ok)throw new Error(r.status);
  const j=await r.json();const n=parseInt(String(j.tag_name).replace(/\D/g,''),10)||0;
  const a=(j.assets||[]).find(x=>/\.apk$/i.test(x.name));
  UPD=(n>BUILD.n&&a)?{n,url:a.browser_download_url}:null;
  if(manual)toast(UPD?'New version found':'You have the latest version');
  if(S.profile&&['','home','more'].includes(location.hash.slice(1)))render(true);
 }catch(e){if(manual)toast('Could not check. Needs internet and a public repository.')}}
function openUpd(){if(UPD)window.open(UPD.url,'_blank')}
const updBanner=()=>UPD?`<div class="card warnbox"><b>Update available</b><div class="mu">Build ${UPD.n} is ready.</div><button class="btn full" onclick="openUpd()">Download update</button></div>`:'';

// ---------- Views ----------
const V={};
V.home=()=>{const today=new Date().toISOString().slice(0,10);
 const fu=S.customers.filter(c=>c.followup&&c.followup<=today);
 return`<div class="row"><img class="logo" src="icons/icon-192.png" alt="CARM"><h1 style="margin:0">${t('welcome')}${S.profile.city?', '+esc(S.profile.city):''}</h1></div>${updBanner()}
 <div class="grid g3"><div class="card stat"><div class="big">${S.customers.length}</div><div class="mu">${t('customers')}</div></div>
 <div class="card stat"><div class="big">${S.stock.filter(s=>s.status==='Available').length}</div><div class="mu">In stock</div></div>
 <div class="card stat"><div class="big">${fu.length}</div><div class="mu">Due today</div></div></div>
 <h2>Quick actions</h2><div class="grid">
 <div class="tile wide" onclick="go('find')">${ic('search')}${t('find')}</div>
 <div class="tile" onclick="go('addc')">${ic('userplus')}${t('addc')}</div>
 <div class="tile" onclick="go('addv')">${ic('car')}${t('addv')}</div></div>
 ${fu.length?`<h2>Today's follow-ups</h2>`+fu.map(c=>`<div class="card">${esc(c.name)} <span class="mu">${esc(c.phone)}</span></div>`).join(''):''}`};

let EX={tab:'cars',bq:'',q:'',fuel:'',trans:'',year:'',seats:'',safety:''};
const STOP=new Set(['car','cars','safety','star','stars','seater','seats','seat','rating','with','and','the','for']);
function parseQ(q){q=q.toLowerCase();const f={};let m;
 m=q.match(/(\d)\s*-?\s*(?:seater|seats?)\b/)||q.match(/\bseats?\s*(\d)/);if(m){f.seats=+m[1];q=q.replace(m[0],' ')}
 m=q.match(/(\d)\s*-?\s*stars?\b/)||q.match(/\bsafety\s*(\d)/);if(m){f.safety=+m[1];q=q.replace(m[0],' ')}
 return{f,toks:q.split(/[^a-z0-9.+]+/).filter(x=>x&&!STOP.has(x))}}
const carBlob=c=>[c.make,c.model,c.variant,c.type,c.fuel,c.trans,c.trans==='Manual'?'manual':'automatic auto',c.year].join(' ').toLowerCase();
function exploreList(){const{f,toks}=parseQ(EX.q);
 return allCars().filter(c=>{
  if(f.seats&&c.seats!==f.seats)return false;
  if(f.safety&&c.safety!==f.safety)return false;
  const b=carBlob(c);
  if(!toks.every(x=>/^(19|20)\d\d$/.test(x)?String(c.year)===x:b.includes(x)))return false;
  if(EX.fuel&&c.fuel!==EX.fuel)return false;
  if(EX.trans==='Manual'&&c.trans!=='Manual')return false;
  if(EX.trans==='Automatic'&&c.trans==='Manual')return false;
  if(EX.year&&String(c.year)!==EX.year)return false;
  if(EX.seats&&String(c.seats)!==EX.seats)return false;
  if(EX.safety&&c.safety<+EX.safety)return false;
  return true}).sort((a,b)=>a.price-b.price)}
V.explore=()=>{if(EX.tab==='brands')return brandsView();const l=exploreList();
 const uniq=k=>[...new Set(allCars().map(c=>c[k]))].sort();
 const sel=(k,lab,list,fmt)=>`<select aria-label="${lab}" onchange="EX.${k}=this.value;render(true)"><option value="">${lab}</option>${list.map(x=>`<option value="${esc(x)}" ${String(EX[k])===String(x)?'selected':''}>${esc(fmt?fmt(x):x)}</option>`).join('')}</select>`;
 return`<h1>${t('explore')}</h1>${tabBar()}<div class="card warnbox mu">Demo catalogue: fictional cars for testing. Real verified data is planned for a later step.</div>
 <input id="q" placeholder="Search: diesel manual 2025, 7 seater, 5 star" value="${esc(EX.q)}" oninput="EX.q=this.value;render(true)">
 <div class="grid f">${sel('fuel','Fuel',FUELS)}${sel('trans','Gearbox',['Manual','Automatic'],x=>x==='Automatic'?'Automatic (incl. AMT, CVT, DCT)':x)}${sel('year','Year',uniq('year'))}${sel('seats','Seats',uniq('seats'),x=>x+' seats')}${sel('safety','Safety',[3,4,5],x=>x+' star or more')}</div>
 <div class="mu">${l.length} car${l.length===1?'':'s'} found</div>`+(l.map(carCard).join('')||'<p class="mu">No cars match. Try fewer words.</p>')};
function carCard(c,extra=''){return`<div class="card tap" onclick="go('car/${c.id}')"><div class="photo">${esc(c.type)}</div><b>${esc(c.make)} ${esc(c.model)}</b> ${esc(c.variant)}
 <div class="big">${money(c.price)}</div><div>${[c.year,c.fuel,c.trans,c.seats+' seats',c.safety+' star safety'].map(x=>`<span class="chip">${esc(x)}</span>`).join('')}</div>
 <div>${c.features.map(x=>`<span class="chip">${esc(x)}</span>`).join('')}</div>
 <div class="mu">Status: ${esc(c.status)} · Source: ${esc(c.src.name)} (${c.src.verified?'verified':'unverified'})</div>${extra}<div class="more">View details</div></div>`}

V.customers=()=>`<h1>${t('customers')}</h1><button class="btn full" onclick="go('addc')">+ ${t('addc')}</button>`+
 (S.customers.map(c=>`<div class="card"><div class="row sp"><b>${esc(c.name)}</b><span class="chip warn">${esc(c.stage)}</span></div>
 <div class="mu">${esc(c.phone)} · ${esc(c.city)}</div>${c.notes?`<div>${esc(c.notes)}</div>`:''}
 ${S.demands.filter(d=>d.cid===c.id).map(d=>`<div class="mu">Saved demand: ${esc(d.summary)}</div>`).join('')}
 <div class="row"><select onchange="setStage('${c.id}',this.value)">${opts(STAGES,c.stage)}</select>
 <input type="date" value="${esc(c.followup||'')}" onchange="setFu('${c.id}',this.value)"></div></div>`).join('')||'<p class="mu">No customers yet.</p>');
V.addc=()=>`<h1>${t('addc')}</h1><label>Full name</label><input id="cn"><label>Phone</label><input id="cp" type="tel"><label>City</label><input id="cc" value="${esc(S.profile.city)}">
 <label>Notes (optional)</label><textarea id="cno"></textarea><button class="btn full" onclick="saveC()">Save</button>`;

V.stock=()=>`<h1>${t('stock')}</h1><button class="btn full" onclick="go('addv')">+ ${t('addv')}</button>`+
 (S.stock.map(s=>`<div class="card"><div class="row sp"><b>${esc(s.make)} ${esc(s.model)} ${esc(s.variant)}</b><span class="chip ${s.status==='Available'?'ok':''}">${esc(s.status)}</span></div>
 <div>${esc(s.cond)} · ${esc(s.year)} · ${s.km?esc(s.km)+' km':''}</div><div class="big">${money(s.price)}</div>
 <select onchange="setSt('${s.id}',this.value)">${opts(['Available','Reserved','Sold','Under Inspection','Pending Approval','Unavailable'],s.status)}</select></div>`).join('')||'<p class="mu">No vehicles yet.</p>');
V.addv=()=>`<h1>${t('addv')}</h1><label>New or used</label><select id="vc"><option>New</option><option>Used</option></select>
 <label>Make</label><input id="vm"><label>Model</label><input id="vmo"><label>Variant</label><input id="vv"><label>Year</label><input id="vy" type="number" value="${new Date().getFullYear()}">
 <label>Kilometres (used only)</label><input id="vk" type="number"><label>Selling price (₹)</label><input id="vp" type="number">
 <button class="btn full" onclick="saveV()">Save</button>`;

V.more=()=>`<h1>${t('more')}</h1><div class="card"><label>Mode</label><select onchange="S.set.mode=this.value;save();applySettings();render()">
 <option value="simple" ${S.set.mode==='simple'?'selected':''}>Simple (large buttons, guided)</option><option value="pro" ${S.set.mode==='pro'?'selected':''}>Professional (more detail)</option></select>
 <label>Theme</label><select onchange="S.set.theme=this.value;save();applySettings()">${['system','light','dark'].map(x=>`<option ${S.set.theme===x?'selected':''}>${x}</option>`).join('')}</select>
 <label>Text size: ${S.set.text}%</label><input type="range" min="90" max="150" step="10" value="${S.set.text}" oninput="S.set.text=+this.value;save();applySettings()">
 <label>Language</label><select onchange="S.set.lang=this.value;save();render()"><option value="en" ${S.set.lang==='en'?'selected':''}>English</option><option value="hi" ${S.set.lang==='hi'?'selected':''}>हिन्दी</option></select></div>
 <div class="card"><b>Location</b><div class="mu">${esc(S.profile.city)}, ${esc(S.profile.state)}, ${esc(S.profile.country)}</div><button class="btn alt" onclick="S.profile=null;save();render()">Change country / region</button></div>
 <div class="card"><b>Your data</b><div class="mu">Saved only on this device. Export a backup regularly.</div><button class="btn alt" onclick="exportData()">Download backup</button></div>
 <div class="card"><b>App version</b><div class="mu">CARM v0.4.0 · build ${BUILD.n||'local'}</div>${UPD?`<div class="card warnbox">New build ${UPD.n} is ready. Tap Download, then open the downloaded file to install. Your saved data stays.</div><button class="btn full" onclick="openUpd()">Download update</button>`:''}<button class="btn alt full" onclick="checkUpdate(true)">Check for updates</button></div>`;

// ---------- Car, company and model pages ----------
const slug=x=>x.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
const kv=(k,v)=>`<div class="kv"><span>${esc(k)}</span><b>${esc(v)}</b></div>`;
const backBtn=()=>`<button class="btn alt" style="margin-bottom:12px" onclick="back()">Back</button>`;
const nf=()=>`${backBtn()}<p class="mu">Page not found.</p>`;
function back(){if(history.length>1)history.back();else go('explore')}
const tabBar=()=>`<div class="seg"><button class="${EX.tab!=='brands'?'on':''}" onclick="EX.tab='cars';render()">Cars</button><button class="${EX.tab==='brands'?'on':''}" onclick="EX.tab='brands';render()">Companies</button></div>`;
function brandsView(){const q=EX.bq.toLowerCase();
 const l=BRANDS.filter(b=>!q||(b.name+' '+b.models.map(m=>m[0]).join(' ')).toLowerCase().includes(q));
 return`<h1>${t('explore')}</h1>${tabBar()}<div class="card warnbox mu">Company and model names are from general knowledge and are NOT verified. Prices and full specs will come from official or licensed data.</div>
 <input id="bq" placeholder="Search company or model" value="${esc(EX.bq)}" oninput="EX.bq=this.value;render(true)">
 <div class="mu" style="margin-bottom:10px">${l.length} companies</div><div class="grid">${l.map(b=>`<div class="tile brand" onclick="go('brand/${slug(b.name)}')"><span class="badge">${esc(b.name[0])}</span>${esc(b.name)}<span class="mu">${b.models.length} models</span></div>`).join('')}</div>`}
V.brand=s=>{const b=BRANDS.find(x=>slug(x.name)===s);if(!b)return nf();
 return`${backBtn()}<div class="row" style="margin-bottom:8px"><span class="badge lg">${esc(b.name[0])}</span><div><h1 style="margin:0">${esc(b.name)}</h1><div class="mu">${esc(b.country)}</div></div></div>
 <div class="card warnbox mu">India model list, unverified.</div><h2>Models (${b.models.length})</h2>`+
 b.models.map(m=>`<div class="card tap" onclick="go('model/${s}/${slug(m[0])}')"><div class="row sp"><b>${esc(m[0])}</b><span class="chip">${esc(m[1])}</span></div><div class="mu">${esc(m[2].length?m[2].join(', '):'Fuel options not listed')}</div></div>`).join('')};
V.model=(s,ms)=>{const b=BRANDS.find(x=>slug(x.name)===s);const m=b&&b.models.find(x=>slug(x[0])===ms);if(!m)return nf();
 const demo=allCars().filter(c=>c.make===b.name);
 return`${backBtn()}<div class="photo">${esc(m[1])}</div><h1 style="margin-bottom:4px">${esc(b.name)} ${esc(m[0])}</h1>
 <div class="card"><h2 style="margin-top:0">Overview</h2>${kv('Company',b.name)}${kv('Company country',b.country)}${kv('Body type',m[1])}${kv('Fuel options',m[2].length?m[2].join(', '):'Not listed')}</div>
 <div class="card"><h2 style="margin-top:0">Variants, prices, features</h2><div class="mu">Not loaded yet. They will come from official or licensed data in a later step, with source and date.</div></div>
 <div class="card"><h2 style="margin-top:0">Market availability</h2>${kv('India','Availability Unverified')}</div>
 <div class="card"><h2 style="margin-top:0">Source and last updated</h2>${kv('Source','CARM name list (general knowledge)')}${kv('Verified','No')}${kv('Last updated','2026-11-16')}</div>
 <h2>More from ${esc(b.name)}</h2>`+b.models.filter(x=>x!==m).map(x=>`<div class="card tap" onclick="go('model/${s}/${slug(x[0])}')"><div class="row sp"><b>${esc(x[0])}</b><span class="chip">${esc(x[1])}</span></div></div>`).join('')};
V.car=id=>{const c=allCars().find(x=>x.id===id);if(!c)return nf();
 const same=allCars().filter(x=>x.make===c.make&&x.model===c.model&&x.id!==c.id);
 const others=allCars().filter(x=>x.make===c.make&&x.model!==c.model);
 const li=x=>`<div class="card tap" onclick="go('car/${x.id}')"><div class="row sp"><b>${esc(x.model)} ${esc(x.variant)}</b><span>${money(x.price)}</span></div></div>`;
 return`${backBtn()}<div class="photo">${esc(c.type)}</div><h1 style="margin-bottom:4px">${esc(c.make)} ${esc(c.model)}</h1><div class="mu" style="margin-bottom:10px">${esc(c.variant)} - ${esc(c.year)}</div>
 <div class="card"><h2 style="margin-top:0">Overview</h2>${kv('Body type',c.type)}${kv('Fuel',c.fuel)}${kv('Gearbox',c.trans)}${GLOSS[c.trans]?`<div class="mu">${esc(GLOSS[c.trans])}</div>`:''}${kv('Seats',c.seats)}${kv('Model year',c.year)}</div>
 <div class="card"><h2 style="margin-top:0">Pricing</h2>${kv('Ex-showroom (demo)',money(c.price))}<div class="mu">Demo price. On-road, RTO and insurance estimates come with real data.</div></div>
 <div class="card"><h2 style="margin-top:0">Specifications</h2>${kv('Mileage',c.mileage?c.mileage+' km/l':'Electric (range not loaded)')}${kv('Safety rating',c.safety+' star')}</div>
 <div class="card"><h2 style="margin-top:0">Features</h2>${c.features.map(x=>`<span class="chip">${esc(x)}</span>`).join('')}</div>
 <div class="card"><h2 style="margin-top:0">Market availability</h2>${kv('Country',S.profile.country)}${kv('Status',c.status)}</div>
 <div class="card"><h2 style="margin-top:0">Source and last updated</h2>${kv('Source',c.src.name)}${kv('Verified',c.src.verified?'Yes':'No')}${kv('Last updated',c.src.updated)}</div>
 ${same.length?'<h2>Other variants</h2>'+same.map(li).join(''):''}${others.length?'<h2>More from '+esc(c.make)+'</h2>'+others.map(li).join(''):''}`};

// ---------- Matcher ----------
const imp=id=>`<select id="${id}"><option value="">Don't care</option><option value="p">Preferred</option><option value="m">Must have</option></select>`;
V.find=()=>`<h1>${t('find')}</h1><div class="card warnbox mu">For each item choose <b>Must have</b> (cannot be broken) or <b>Preferred</b> (nice to have).</div>
 <div class="row"><div style="flex:1"><label>Min budget (₹)</label><input id="bmin" type="number" value="500000"></div><div style="flex:1"><label>Max budget (₹)</label><input id="bmax" type="number" value="1300000"></div></div>
 ${[['type','Body type',TYPES],['fuel','Fuel',FUELS],['trans','Transmission',TRANS]].map(([k,l,a])=>`<label>${l}</label><div class="row"><select id="f_${k}" style="flex:2"><option value="">Any</option>${opts(a)}</select><div style="flex:1">${imp('i_'+k)}</div></div>`).join('')}
 <label>Minimum seats</label><input id="seats" type="number" value="5">
 <h2>Features</h2>${FEATURES.map(f=>`<div class="row sp"><span>${f}</span><div style="width:45%">${imp('ft_'+f.replace(/\W/g,''))}</div></div>`).join('')}
 <button class="btn full" onclick="runFind()">Find cars</button><div id="res"></div>`;
function criteria(){const c=[];
 for(const k of['type','fuel','trans']){const v=val('f_'+k),i=val('i_'+k);if(v)c.push({k,v,imp:i||'p',label:v})}
 for(const f of FEATURES){const i=val('ft_'+f.replace(/\W/g,''));if(i)c.push({k:'feat',v:f,imp:i,label:f})}
 return c}
const pass=(car,c)=>c.k==='feat'?car.features.includes(c.v):car[c.k]===c.v;
function match(car,cr,min,max,seats){
 if(car.seats<seats)return null; // seats treated as mandatory
 const stretch=car.price>max&&car.price<=max*1.15;
 if(car.price<min||car.price>max*1.15)return null;
 const must=cr.filter(c=>c.imp==='m'),pref=cr.filter(c=>c.imp==='p');
 if(must.some(c=>!pass(car,c)))return null; // mandatory never violated
 const ok=pref.filter(c=>pass(car,c)),miss=pref.filter(c=>!pass(car,c));
 return{car,stretch,ok,miss,must,pts:ok.length,total:pref.length}}
function runFind(){const cr=criteria(),min=+val('bmin')||0,max=+val('bmax')||1e9,seats=+val('seats')||0;
 S.last={cr,min,max,seats};
 const r=allCars().map(c=>match(c,cr,min,max,seats)).filter(Boolean).sort((a,b)=>(b.pts/(b.total||1))-(a.pts/(a.total||1))||a.car.price-b.car.price);
 const perfect=r.filter(x=>!x.stretch&&!x.miss.length),alt=r.filter(x=>!x.stretch&&x.miss.length),str=r.filter(x=>x.stretch);
 const grp=(n,a)=>a.length?`<h2>${n} (${a.length})</h2>`+a.map(x=>carCard(x.car,`<div><b>Why:</b> ${[...x.must.map(c=>'Must have: '+c.label+' (matched)'),...x.ok.map(c=>'Preferred: '+c.label+' (matched)')].map(esc).join(', ')||'Within budget'}</div>
 ${x.miss.length?`<div style="color:var(--er)">Missing: ${x.miss.map(c=>esc(c.label)).join(', ')}</div>`:''}<div class="mu">Score: ${x.pts} of ${x.total} preferences met (no hidden formula)</div>`)).join(''):'';
 const inv=S.stock.filter(s=>s.status==='Available').length;
 $('#res').innerHTML=(grp('Perfect matches',perfect)+grp('Best alternatives',alt)+grp('Budget stretch (up to 15% over)',str))||'<p class="mu">No cars match all "Must have" items in this budget. Try loosening one.</p>';
 $('#res').innerHTML+=`<h2>Save this demand</h2><select id="sc"><option value="">Choose customer</option>${S.customers.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select><button class="btn alt full" onclick="saveD()">Save to customer</button>`}
function saveD(){const cid=val('sc');if(!cid)return toast('Pick a customer');const l=S.last;
 S.demands.push({id:uid(),cid,...l,summary:`₹${l.min}–${l.max}; `+(l.cr.map(c=>(c.imp==='m'?'MUST ':'pref ')+c.label).join(', ')||'no filters')});save();toast('Demand saved')}

// ---------- Actions ----------
const uid=()=>Math.random().toString(36).slice(2,10);
function saveC(){const n=val('cn').trim();if(!n)return toast('Enter a name');S.customers.unshift({id:uid(),name:n,phone:val('cp').trim(),city:val('cc').trim(),notes:val('cno').trim(),stage:STAGES[0],followup:'',created:Date.now()});save();toast('Saved');go('customers')}
function saveV(){if(!val('vmo').trim())return toast('Enter a model');S.stock.unshift({id:uid(),cond:val('vc'),make:val('vm').trim(),model:val('vmo').trim(),variant:val('vv').trim(),year:val('vy'),km:val('vk'),price:+val('vp')||0,status:'Available'});save();toast('Saved');go('stock')}
function setStage(id,v){S.customers.find(c=>c.id===id).stage=v;save()}
function setFu(id,v){S.customers.find(c=>c.id===id).followup=v;save()}
function setSt(id,v){S.stock.find(c=>c.id===id).status=v;save();render(true)}
function exportData(){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(S,null,2)],{type:'application/json'}));a.download='carm-backup-'+new Date().toISOString().slice(0,10)+'.json';a.click()}
function go(p){location.hash='#'+p}
// ---------- Router ----------
const NAV=[['home','home'],['explore','compass'],['customers','users'],['stock','car'],['more','dots']];
function render(keepFocus){
 if(!S.profile)return onboarding();
 const p=(location.hash||'#home').slice(1);const[r,...ar]=p.split('/');const v=()=>(V[r]||V.home)(...ar.map(decodeURIComponent));
 $('#nav').classList.remove('hide');
 const base=['addc','find'].includes(r)?'customers':r==='addv'?'stock':['car','brand','model'].includes(r)?'explore':r;
 $('#nav').innerHTML=NAV.map(([k,i])=>`<a href="#${k}" class="${k===base?'on':''}">${ic(i)}${t(k)}</a>`).join('');
 const f=document.activeElement,id=f&&f.id,pos=f&&f.selectionStart;
 $('#app').innerHTML=v();
 if(keepFocus&&id){const n=document.getElementById(id);if(n&&n.tagName==='INPUT'){n.focus();try{n.setSelectionRange(pos,pos)}catch(e){}}}
 if(!keepFocus)window.scrollTo(0,0)}
window.addEventListener('hashchange',()=>render());
if(IS_APP){let bt=null;history.replaceState({r:1},'');history.pushState({h:1},'');
 window.addEventListener('popstate',e=>{if(e.state&&e.state.r){toast('Press back again to exit');clearTimeout(bt);bt=setTimeout(()=>{if(history.state&&history.state.r)history.pushState({h:1},'')},2200)}})}
applySettings();render();checkUpdate(false);
if('serviceWorker' in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{});
