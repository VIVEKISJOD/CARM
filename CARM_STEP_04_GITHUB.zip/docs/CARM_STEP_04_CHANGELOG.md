# CARM — Changelog, Step 04
Project: CARM · Step 04 · ZIP: CARM_STEP_04_GITHUB.zip · Version: 0.4.0 · Date: 2026-11-16
## Added
Companies tab in Explore (20 companies, model names, body type, fuel options; unverified); company page; model page; car detail page with 8 sections; tappable car cards; Cars/Companies switch; double-back-to-exit in the Android app.
## Modified
Home and Explore grid layout (equal columns, uniform gaps); Home stat labels shortened (In stock, Due today); sub-page routing (#car/id, #brand/slug, #model/brand/model); Explore tab highlight stays on detail pages; cache v4; version label 0.4.0.
## Fixed
Uneven gaps (third stat card alone, mixed margins).
## Removed
Nothing.
## Security / Backend / Database
None. Data still local only.
## Known issues
Real phone behaviour untested; company data unverified; no real prices/specs.
## Breaking changes
None.
