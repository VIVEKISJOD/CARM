# CARM — Handoff, Step 04
- Project: CARM · Step 04 — Layout fixes, back button, car and company pages · Date: 2026-11-16 · Version: 0.4.0
- ZIP: CARM_STEP_04_GITHUB.zip · Previous step: Step 03 (+02B/02C build.yml fixes). build.yml UNCHANGED in this step (docs/build.yml = current).

## Done
1. Even spacing: all grids use equal columns and one 12px gap (css/styles.css bottom section). Home: 3 equal stat cards (Customers, In stock, Due today), Find tile full width, Add Customer / Add Vehicle side by side. Explore filters in 2 columns, last odd one spans full width.
2. Back button (Android app only, js/app.js near end): a sentinel history entry is added at start; back walks through app screens; at the first screen it shows "Press back again to exit" for ~2 s, a second press exits. No plugin needed. Website uses normal browser back.
3. Explore has two tabs: Cars (demo catalogue, search + filters) and Companies (js/brands.js, 20 real company names with model names, body type, fuel options). Routes: #car/<id>, #brand/<slug>, #model/<brand>/<model>. Every car card is tappable.
4. Car page sections: Overview, Pricing (demo), Specifications, Features, Market availability, Source and last updated, Other variants, More from company. Model page (real names) shows Overview, "Variants, prices, features: not loaded yet", Availability Unverified, Source, More from company.

## Files changed/added
js/app.js, js/brands.js (new), css/styles.css, index.html, sw.js (cache v4), docs/.

## IMPORTANT data honesty
js/brands.js is a NAME list compiled from general knowledge, marked unverified everywhere in the UI. Luxury models have no fuel list on purpose. Cars in js/data.js are fictional DEMO cars (make "Demo"). No real prices or specs exist yet. Next data step must use official or licensed sources and record source + date.

## Not verified
Tested with a stubbed-DOM script in Node: all routes render without errors, expected text present, no emoji characters, back-handler fires the exit toast. NOT tested on a real phone: real layout spacing, Android back behaviour with WebView history, in-app updater. If back button still exits at once, switch to the @capacitor/app plugin (needs build.yml dependency change).

## Not implemented
Everything in Step 01 list except what later steps added; Hindi partial.

## Next (Step 05)
Customer profile with tabs, Information Shared tracker, follow-up manager. Then real data provider design.
