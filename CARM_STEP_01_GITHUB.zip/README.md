# CARM
Automotive sales, customer and stock app (India first). Runs in any browser and installs on Android/PC as an app (PWA). No build step needed.

## Put it online (GitHub Pages)
1. Create a GitHub repository and upload everything from this ZIP (unzipped) to the `main` branch.
2. Repository **Settings → Pages → Source: GitHub Actions**.
3. Wait ~1 minute (Actions tab). Your link: `https://<username>.github.io/<repo>/`

## Install as an app
- Android Chrome: open the link → menu ⋮ → **Install app**.
- PC Chrome/Edge: install icon in the address bar.

## Logo
Replace `icons/icon-192.png` and `icons/icon-512.png` (square PNGs, same names). Current icons are placeholders made from your sample image.

## Data
Everything is stored on the device only (browser storage). Use **More → Download backup**. The Explore catalogue is DEMO data (fictional cars), not real.

See `docs/` for handoff and changelog.
