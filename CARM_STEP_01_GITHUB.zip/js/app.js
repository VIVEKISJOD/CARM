'use strict';
const KEY='carm_v1';
const T={en:{home:'Home',explore:'Explore',customers:'Customers',stock:'Stock',more:'More',welcome:'Welcome',find:'Find My Customer\'s Car',addc:'Add Customer',addv:'Add Vehicle'},
hi:{home:'होम',explore:'खोजें',customers:'ग्राहक',stock:'स्टॉक',more:'और',welcome:'स्वागत है',find:'ग्राहक की कार खोजें',addc:'ग्राहक जोड़ें',addv:'वाहन जोड़ें'}};
let S=load();
function load(){try{const s=JSON.parse(localStorage.getItem(KEY));if(s)return s}catch(e){}
 return{profile:null,set:{mode:'simple',theme:'system',text:100,lang:'en'},customers:[],stock:[],demands:[]}}
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){toast('Could not save')}}
const t=k=>(T[S.set.lang]||T.en)[k]||T.en[k]||k;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const $=s=>document.querySelector(s);
const money=n=>'₹'+Number(n).toLocaleString((COUNTRIES[S.profile?.country]||COUNTRIES.India).loc);
function toast(m){const e=$('#toast');e.textContent=m;e.classList.add('on');setTimeout(()=>e.classList.remove('on'),1800)}
function applySettings(){const b=document.body;b.className=[S.set.mode,S.set.theme==='dark'?'dark':S.set.theme==='system'?'sys':''].join(' ');
 document.documentElement.style.setProperty('--fs',S.set.text+'%');document.documentElement.lang=S.set.lang}
const allCars=()=>DEMO_CARS;
const opts=(a,sel)=>a.map(x=>`<option ${x===sel?'selected':''}>${esc(x)}</option>`).join('');
const val=id=>($('#'+id)||{}).value;

// ---------- Onboarding ----------
function onboarding(){
 $('#nav').classList.add('hide');
 $('#app').innerHTML=`<h1>Welcome to CARM</h1><p class="mu">Let's set up your app. It takes 20 seconds.</p>
 <label>Country</label><select id="oc">${opts(Object.keys(COUNTRIES),'India')}</select>
 <label>State / region</label><select id="os"></select>
 <label>City</label><input id="ocity" placeholder="e.g. Pune">
 <label>Language</label><select id="ol"><option value="en">English</option><option value="hi">हिन्दी</option></select>
 <button class="btn full" id="od">Start</button>`;
 const fillS=()=>$('#os').innerHTML=opts(COUNTRIES[val('oc')].states);fillS();$('#oc').onchange=fillS;
 $('#od').onclick=()=>{S.profile={country:val('oc'),state:val('os'),city:val('ocity').trim()};S.set.lang=val('ol');save();applySettings();location.hash='#home';render()}}

// ---------- Views ----------
const V={};
V.home=()=>{const today=new Date().toISOString().slice(0,10);
 const fu=S.customers.filter(c=>c.followup&&c.followup<=today);
 return`<h1>${t('welcome')}${S.profile.city?', '+esc(S.profile.city):''}</h1>
 <div class="grid"><div class="card"><div class="big">${S.customers.length}</div><div class="mu">${t('customers')}</div></div>
 <div class="card"><div class="big">${S.stock.filter(s=>s.status==='Available').length}</div><div class="mu">Available stock</div></div>
 <div class="card"><div class="big">${fu.length}</div><div class="mu">Follow-ups due</div></div></div>
 <h2>Quick actions</h2><div class="grid">
 <div class="tile" onclick="go('find')">🔎<br>${t('find')}</div>
 <div class="tile" onclick="go('addc')">👤<br>${t('addc')}</div>
 <div class="tile" onclick="go('addv')">🚗<br>${t('addv')}</div></div>
 ${fu.length?`<h2>Today's follow-ups</h2>`+fu.map(c=>`<div class="card">${esc(c.name)} <span class="mu">${esc(c.phone)}</span></div>`).join(''):''}`};

V.explore=()=>{const q=(S.q||'').toLowerCase();
 const l=allCars().filter(c=>!q||(c.model+c.variant+c.type+c.fuel).toLowerCase().includes(q));
 return`<h1>${t('explore')}</h1><div class="card warnbox mu">Demo catalogue: fictional cars for testing. Real verified data is planned for a later step.</div>
 <input placeholder="Search model, type, fuel…" value="${esc(S.q||'')}" oninput="S.q=this.value;render(true)">`+l.map(carCard).join('')};
function carCard(c,extra=''){return`<div class="card"><div class="photo">${esc(c.type)}</div><b>${esc(c.make)} ${esc(c.model)}</b> ${esc(c.variant)}
 <div class="big">${money(c.price)}</div><div>${[c.fuel,c.trans,c.seats+' seats',c.safety+'★ safety'].map(x=>`<span class="chip">${esc(x)}</span>`).join('')}</div>
 <div>${c.features.map(x=>`<span class="chip">${esc(x)}</span>`).join('')}</div>
 <div class="mu">Status: ${esc(c.status)} · Source: ${esc(c.src.name)} (${c.src.verified?'verified':'unverified'})</div>${extra}</div>`}

V.customers=()=>`<h1>${t('customers')}</h1><button class="btn full" onclick="go('addc')">+ ${t('addc')}</button>`+
 (S.customers.map(c=>`<div class="card"><div class="row sp"><b>${esc(c.name)}</b><span class="chip warn">${esc(c.stage)}</span></div>
 <div class="mu">${esc(c.phone)} · ${esc(c.city)}</div>${c.notes?`<div>${esc(c.notes)}</div>`:''}
 ${S.demands.filter(d=>d.cid===c.id).map(d=>`<div class="mu">Saved demand: ${esc(d.summary)}</div>`).join('')}
 <div class="row"><select onchange="setStage('${c.id}',this.value)">${opts(STAGES,c.stage)}</select>
 <input type="date" value="${esc(c.followup||'')}" onchange="setFu('${c.id}',this.value)"></div></div>`).join('')||'<p class="mu">No customers yet.</p>');
V.addc=()=>`<h1>${t('addc')}</h1><label>Full name</label><input id="cn"><label>Phone</label><input id="cp" type="tel"><label>City</label><input id="cc" value="${esc(S.profile.city)}">
 <label>Notes (optional)</label><textarea id="cno"></textarea><button class="btn full" onclick="saveC()">Save</button>`;

V.stock=()=>`<h1>${t('stock')}</h1><button class="btn full" onclick="go('addv')">+ ${t('addv')}</button>`+
 (S.stock.map(s=>`<div class="card"><div class="row sp"><b>${esc(s.make)} ${esc(s.model)} ${esc(s.variant)}</b><span class="chip ${s.status==='Available'?'ok':''}">${esc(s.status)}</span></div>
 <div>${esc(s.cond)} · ${esc(s.year)} · ${s.km?esc(s.km)+' km':''}</div><div class="big">${money(s.price)}</div>
 <select onchange="setSt('${s.id}',this.value)">${opts(['Available','Reserved','Sold','Under Inspection','Pending Approval','Unavailable'],s.status)}</select></div>`).join('')||'<p class="mu">No vehicles yet.</p>');
V.addv=()=>`<h1>${t('addv')}</h1><label>New or used</label><select id="vc"><option>New</option><option>Used</option></select>
 <label>Make</label><input id="vm"><label>Model</label><input id="vmo"><label>Variant</label><input id="vv"><label>Year</label><input id="vy" type="number" value="${new Date().getFullYear()}">
 <label>Kilometres (used only)</label><input id="vk" type="number"><label>Selling price (₹)</label><input id="vp" type="number">
 <button class="btn full" onclick="saveV()">Save</button>`;

V.more=()=>`<h1>${t('more')}</h1><div class="card"><label>Mode</label><select onchange="S.set.mode=this.value;save();applySettings();render()">
 <option value="simple" ${S.set.mode==='simple'?'selected':''}>Simple (large buttons, guided)</option><option value="pro" ${S.set.mode==='pro'?'selected':''}>Professional (more detail)</option></select>
 <label>Theme</label><select onchange="S.set.theme=this.value;save();applySettings()">${['system','light','dark'].map(x=>`<option ${S.set.theme===x?'selected':''}>${x}</option>`).join('')}</select>
 <label>Text size: ${S.set.text}%</label><input type="range" min="90" max="150" step="10" value="${S.set.text}" oninput="S.set.text=+this.value;save();applySettings()">
 <label>Language</label><select onchange="S.set.lang=this.value;save();render()"><option value="en" ${S.set.lang==='en'?'selected':''}>English</option><option value="hi" ${S.set.lang==='hi'?'selected':''}>हिन्दी</option></select></div>
 <div class="card"><b>Location</b><div class="mu">${esc(S.profile.city)}, ${esc(S.profile.state)}, ${esc(S.profile.country)}</div><button class="btn alt" onclick="S.profile=null;save();render()">Change country / region</button></div>
 <div class="card"><b>Your data</b><div class="mu">Saved only on this device. Export a backup regularly.</div><button class="btn alt" onclick="exportData()">Download backup</button></div>
 <div class="card mu">CARM v0.1.0 · Step 1</div>`;

// ---------- Matcher ----------
const imp=id=>`<select id="${id}"><option value="">Don't care</option><option value="p">Preferred</option><option value="m">Must have</option></select>`;
V.find=()=>`<h1>${t('find')}</h1><div class="card warnbox mu">For each item choose <b>Must have</b> (cannot be broken) or <b>Preferred</b> (nice to have).</div>
 <div class="row"><div style="flex:1"><label>Min budget (₹)</label><input id="bmin" type="number" value="500000"></div><div style="flex:1"><label>Max budget (₹)</label><input id="bmax" type="number" value="1300000"></div></div>
 ${[['type','Body type',TYPES],['fuel','Fuel',FUELS],['trans','Transmission',TRANS]].map(([k,l,a])=>`<label>${l}</label><div class="row"><select id="f_${k}" style="flex:2"><option value="">Any</option>${opts(a)}</select><div style="flex:1">${imp('i_'+k)}</div></div>`).join('')}
 <label>Minimum seats</label><input id="seats" type="number" value="5">
 <h2>Features</h2>${FEATURES.map(f=>`<div class="row sp"><span>${f}</span><div style="width:45%">${imp('ft_'+f.replace(/\W/g,''))}</div></div>`).join('')}
 <button class="btn full" onclick="runFind()">Find cars</button><div id="res"></div>`;
function criteria(){const c=[];
 for(const k of['type','fuel','trans']){const v=val('f_'+k),i=val('i_'+k);if(v)c.push({k,v,imp:i||'p',label:v})}
 for(const f of FEATURES){const i=val('ft_'+f.replace(/\W/g,''));if(i)c.push({k:'feat',v:f,imp:i,label:f})}
 return c}
const pass=(car,c)=>c.k==='feat'?car.features.includes(c.v):car[c.k]===c.v;
function match(car,cr,min,max,seats){
 if(car.seats<seats)return null; // seats treated as mandatory
 const stretch=car.price>max&&car.price<=max*1.15;
 if(car.price<min||car.price>max*1.15)return null;
 const must=cr.filter(c=>c.imp==='m'),pref=cr.filter(c=>c.imp==='p');
 if(must.some(c=>!pass(car,c)))return null; // mandatory never violated
 const ok=pref.filter(c=>pass(car,c)),miss=pref.filter(c=>!pass(car,c));
 return{car,stretch,ok,miss,must,pts:ok.length,total:pref.length}}
function runFind(){const cr=criteria(),min=+val('bmin')||0,max=+val('bmax')||1e9,seats=+val('seats')||0;
 S.last={cr,min,max,seats};
 const r=allCars().map(c=>match(c,cr,min,max,seats)).filter(Boolean).sort((a,b)=>(b.pts/(b.total||1))-(a.pts/(a.total||1))||a.car.price-b.car.price);
 const perfect=r.filter(x=>!x.stretch&&!x.miss.length),alt=r.filter(x=>!x.stretch&&x.miss.length),str=r.filter(x=>x.stretch);
 const grp=(n,a)=>a.length?`<h2>${n} (${a.length})</h2>`+a.map(x=>carCard(x.car,`<div><b>Why:</b> ${[...x.must.map(c=>'Must: '+c.label+' ✓'),...x.ok.map(c=>'Preferred: '+c.label+' ✓')].map(esc).join(', ')||'Within budget'}</div>
 ${x.miss.length?`<div style="color:var(--er)">Missing: ${x.miss.map(c=>esc(c.label)).join(', ')}</div>`:''}<div class="mu">Score: ${x.pts} of ${x.total} preferences met (no hidden formula)</div>`)).join(''):'';
 const inv=S.stock.filter(s=>s.status==='Available').length;
 $('#res').innerHTML=(grp('Perfect matches',perfect)+grp('Best alternatives',alt)+grp('Budget stretch (up to 15% over)',str))||'<p class="mu">No cars match all "Must have" items in this budget. Try loosening one.</p>';
 $('#res').innerHTML+=`<h2>Save this demand</h2><select id="sc"><option value="">Choose customer</option>${S.customers.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select><button class="btn alt full" onclick="saveD()">Save to customer</button>`}
function saveD(){const cid=val('sc');if(!cid)return toast('Pick a customer');const l=S.last;
 S.demands.push({id:uid(),cid,...l,summary:`₹${l.min}–${l.max}; `+(l.cr.map(c=>(c.imp==='m'?'MUST ':'pref ')+c.label).join(', ')||'no filters')});save();toast('Demand saved')}

// ---------- Actions ----------
const uid=()=>Math.random().toString(36).slice(2,10);
function saveC(){const n=val('cn').trim();if(!n)return toast('Enter a name');S.customers.unshift({id:uid(),name:n,phone:val('cp').trim(),city:val('cc').trim(),notes:val('cno').trim(),stage:STAGES[0],followup:'',created:Date.now()});save();toast('Saved');go('customers')}
function saveV(){if(!val('vmo').trim())return toast('Enter a model');S.stock.unshift({id:uid(),cond:val('vc'),make:val('vm').trim(),model:val('vmo').trim(),variant:val('vv').trim(),year:val('vy'),km:val('vk'),price:+val('vp')||0,status:'Available'});save();toast('Saved');go('stock')}
function setStage(id,v){S.customers.find(c=>c.id===id).stage=v;save()}
function setFu(id,v){S.customers.find(c=>c.id===id).followup=v;save()}
function setSt(id,v){S.stock.find(c=>c.id===id).status=v;save();render(true)}
function exportData(){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(S,null,2)],{type:'application/json'}));a.download='carm-backup-'+new Date().toISOString().slice(0,10)+'.json';a.click()}
function go(p){location.hash='#'+p}
// ---------- Router ----------
const NAV=[['home','🏠'],['explore','🧭'],['customers','👥'],['stock','🚗'],['more','⋯']];
function render(keepFocus){
 if(!S.profile)return onboarding();
 const p=(location.hash||'#home').slice(1);const v=V[p]||V.home;
 $('#nav').classList.remove('hide');
 const base=['addc','find'].includes(p)?'customers':p==='addv'?'stock':p;
 $('#nav').innerHTML=NAV.map(([k,i])=>`<a href="#${k}" class="${k===base?'on':''}"><b>${i}</b>${t(k)}</a>`).join('');
 const f=document.activeElement,id=f&&f.id,pos=f&&f.selectionStart;
 $('#app').innerHTML=v();
 if(keepFocus&&f&&f.tagName==='INPUT'){const n=document.querySelector('#app input[placeholder]');if(n){n.focus();n.setSelectionRange(pos,pos)}}
 if(!keepFocus)window.scrollTo(0,0)}
window.addEventListener('hashchange',()=>render());
applySettings();render();
if('serviceWorker' in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{});
